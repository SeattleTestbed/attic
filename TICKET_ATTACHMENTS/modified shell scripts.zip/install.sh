#!/bin/sh

which_out=`which python2`
# Test if they are on archlinux, which uses python2 instead of python.
if [ "$which_out" = "" ]; then
  which_out=`which python`
  if [ "$which_out" = "" ]; then
      echo seattle requires that python be installed on your computer.
      echo Please install python and try again.
  else
      cd "`echo $0 | sed 's/install.sh//'`"
      python seattleinstaller.py $*
  fi
else
    cd "`echo $0 | sed 's/install.sh//'`"
    python2 seattleinstaller.py $*
fi
exit
