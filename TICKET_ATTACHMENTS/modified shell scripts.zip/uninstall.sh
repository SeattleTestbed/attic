#!/bin/sh

cd "`echo $0 | sed 's/uninstall.sh//'`"

which_out=`which python2`
# Test if they are on archlinux, which uses python2 instead of python.
if [ "$which_out" = "" ]; then
  python seattleuninstaller.py $*
else
  python2 seattleuninstaller.py $*
fi
