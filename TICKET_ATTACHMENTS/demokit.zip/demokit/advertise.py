"""
Author: Justin Cappos

Start Date: October 14, 2008

Description:
A stub that allows different announcement types.   I'd make this smarter, but
the user won't configure it, right?

"""

from repyportability import *

import openDHTadvertise
#begin include centralizedadvertise.repy
""" 
Author: Justin Cappos

Start Date: July 8, 2008

Description:
Advertisements to a central server (similar to openDHT)


"""

#begin include session.repy
# This module wraps communications in a signaling protocol.   The purpose is to
# overlay a connection-based protocol with explicit message signaling.   
#
# The protocol is to send the size of the message followed by \n and then the
# message itself.   The size of a message must be able to be stored in 
# sessionmaxdigits.   A size of -1 indicates that this side of the connection
# should be considered closed.
#
# Note that the client will block while sending a message, and the receiver 
# will block while recieving a message.   
#
# While it should be possible to reuse the connectionbased socket for other 
# tasks so long as it does not overlap with the time periods when messages are 
# being sent, this is inadvisable.

class SessionEOF(Exception):
  pass

sessionmaxdigits = 20

# get the next message off of the socket...
def session_recvmessage(socketobj):

  messagesizestring = ''
  # first, read the number of characters...
  for junkcount in range(sessionmaxdigits):
    currentbyte = socketobj.recv(1)

    if currentbyte == '\n':
      break
    
    # not a valid digit
    if currentbyte not in '0123456789' and messagesizestring != '' and currentbyte != '-':
      raise ValueError, "Bad message size"
     
    messagesizestring = messagesizestring + currentbyte

  else:
    # too large
    raise ValueError, "Bad message size"

  messagesize = int(messagesizestring)
  
  # nothing to read...
  if messagesize == 0:
    return ''

  # end of messages
  if messagesize == -1:
    raise SessionEOF, "Connection Closed"

  if messagesize < 0:
    raise ValueError, "Bad message size"

  data = ''
  while len(data) < messagesize:
    chunk =  socketobj.recv(messagesize-len(data))
    if chunk == '': 
      raise SessionEOF, "Connection Closed"
    data = data + chunk

  return data

# a private helper function
def session_sendhelper(socketobj,data):
  sentlength = 0
  # if I'm still missing some, continue to send (I could have used sendall
  # instead but this isn't supported in repy currently)
  while sentlength < len(data):
    thissent = socketobj.send(data[sentlength:])
    sentlength = sentlength + thissent



# send the message 
def session_sendmessage(socketobj,data):
  header = str(len(data)) + '\n'
  session_sendhelper(socketobj,header)

  session_sendhelper(socketobj,data)




#end include session.repy
# I'll use socket timeout to prevent hanging when it takes a long time...
#begin include sockettimeout.repy
"""
<Description>
  Puts back in Python's non-blocking functionality.

  send():
    Raises SocketTimeout Error if the send call lasts
    longer than the set timeout.

  recv():
    Guarentees the receipt of a message.   Raises SocketTimeoutError if it does not
    receive any message before a given timeout.
    If actually receives the message, returns the message and continues.

<Usage>
  Text-replacable for Repy Sockets:
    timeout_openconn(desthost, destport, localip=None, localport=None, timeout = 5)
    timeout_waitforconn(localip, localport, function)

  Object:
    sockobj.settimeout(seconds)
    sockobj.send(data)
    sockobj.recv(bytes)
    sockobj.close()

<Date>
  Sun Mar  1 10:27:35 PST 2009

<Example>
  # hello world
  include sockettimer.repy

  def callback(ip, port, timeout_sockobj, commhandle, listenhandle):
    hw_message = timeout_sockobj.recv(1047)

    # cleanup
    stopcomm(commhandle)
    stopcomm(listenhandle)
    timeout_sockobj.close()

    print hw_message # => "hello world!"
  
  def server():
    sockobj = timeout_waitforconn(getmyip(), 12345, callback)

  def client():
    sockobj = timeout_openconn(getmyip(), 12345)
    sockobj.send("hello world!")

  def main():
    server()
    client()
    exitall()

  if callfunc == 'initialize':
    main() 
"""

class SocketTimeoutError(Exception):
  """The socket timed out before receiving a response"""

def timeout_openconn(desthost, destport, localip=None, localport=None, timeout = 5):
  """
  <Purpose> 
    Wrapper for Repy like socket interface

  <Args>
    Same as Repy openconn

  <Exception>
    Timeout exception if the dest address doesnt respond.

  <Returns>
    socket obj on success
  """

  tsock = TimeoutSocket()
  tsock.settimeout(timeout)
  if localip and localport:
    tsock.bind((localip, localport))
  tsock.connect((desthost, destport))
  return tsock

def timeout_waitforconn(localip, localport, function):
  """
  <Purpose> 
    Wrapper for Repy like socket interface

  <Args>
    Same as Repy waitforconn

  <Side Effects>
    Sets up event listener which calls function on messages.

  <Returns>
    Handle to listener.
  """

  tsock = TimeoutSocket()
  tsock.bind((localip, localport))
  tsock.setcallback(function)
  return tsock.listen()

class TimeoutSocket:
  """
  <Purpose>
    Provide an socket object like the Repy usual one.

  <Side Effects>
    Uses a getlock() to watch for a timeout
    Uses waitforconn and openconn to simulate socket
  """

  ################
  # Constructors
  ################

  def __init__(self):
    """ Constructor for socket """
#    self.lock = getlock() # general lock BUG: Do we need to lock everything?
    self.timeout_lock = getlock() # special lock for Timeout condition
    self.timeout = 5 # seconds to wait
    self.bytes_sent = None # used to check if send() timed out

    # user vars   
    self.local_address = None # ip, port
    self.remote_address = None # ip, port
    self.callback = None # the user's function to call

    # repy socket vars
    self.sockobj = None #  the Repy socket
    self.commhandle = None # the current comm
    self.listencommhandle = None # the listener comm

    #error tracking vars
    
    #if any exceptions are thrown in the separate thread executing _send_and_release, 
    #they are caught and stored in this variable, then raised in _send_or_close
    self.TCPSendError = None

  ################
  # Mutator methods
  #################

  def settimeout(self, value):
    """ Setter for timeout"""
    self.timeout = value

  def setcallback(self, function):
    """ Setter for callback function"""
    self.callback = function

  ####################
  # Public Methods
  ####################

  def bind(self, local_address = None):
    """
    <Purpose>
      Set local address

    <Args>
      Tuple of (ip, port) local.
    """
    self.local_address = local_address

  def listen(self):
    """
    <Purpose>
      Listen for peer
    
    <Side Effects>
      Calls Repy waitforconn()
    """
    return self._waitforconn()

  def connect(self, remote_address):
    """
    <Purpose>
      Connect to peer.

    <Args>
      Tuple of (ip, port) remote.
   
    <Side Effects>
      Calls Repy openconn.
    """
    self.remote_address = remote_address
    self._openconn()

  def recv(self, maxLen): # timeout as optional arg ???
    """
    <Purpose>
      If it fails to finish within the timeout, I close the socket and raise a
      TimeoutError exception. I.e. if there's no message, we call it an error
      and raise it.
      
    <Arguments>
      maxLen - bytes to recv

    <Exception>
      Raises TimeoutError exception if the recv times out
      without receiving a message.

    <Side Effects>
      Closes the connection if times out.

    <Returns>
      The message.
    """
    return self._recv_or_close(maxLen)

  def send(self, data):
    """
    <Purpose>
      Just like normal Repy socket.  Sends messages.
      
    <Arguments>
      data - the string message

    <Exception>
      Same as Repy socket.
 
    <Returns>
      The bytes sent.
    """
    return self._send_or_close(data)

  def close(self):
    self.local_address = None # ip, port
    self.remote_address = None # ip, port
    self.callback = None # the user's function to call

    if self.sockobj:
      self.sockobj.close()
    self.sockobj = None #  the Repy socket
    
    # Armon: As part of the semantics, stopcomm will raise an 
    # exception given an invalid handle, e.g. None. Thus,
    # we need to check for this.
    if self.commhandle: 
      stopcomm(self.commhandle)
      self.commhandle = None # the current comm
    
    # Armon: Same as above.
    if self.listencommhandle:
      stopcomm(self.listencommhandle)
      self.listencommhandle = None # the listener comm


  ########################
  # Private
  #########################

  def _openconn(self):
    """Handle current state variables and call Repy openconn."""

    destip, destport = self.remote_address
    if self.local_address:
      srcip, srcport = self.local_address
      self.sockobj = openconn(destip, destport, srcip, srcport, self.timeout)
    else:
      self.sockobj = openconn(destip, destport)

  def _waitforconn(self):
    """Setup way between Repy waitforconn event"""
    localip, localport = self.local_address
    self.listencommhandle = waitforconn(localip, localport, self._callback)
    return self.listencommhandle

  def _callback(self, ip, port, sockobj, ch, lh):
    """Pass on through to user callback"""
    self.sockobj = sockobj
    self.listencommhandle = lh # same as the 1st from wait for comm, right?
    self.commhandle = ch # should we care?
    
    if not self.remote_address:
      self.remote_address = (ip, port)
    else: 
      raise Exception("what! peer does not match?")

    self.callback(ip, port, self, ch, lh)

  def _send(self, data):
    """Send data"""
    return self.sockobj.send(data)

  def _recv(self, maxLen):
    """Recv data of length maxLen"""
    return self.sockobj.recv(maxLen)

  def _send_and_release(self, data):
    """Send data then release the timeout lock"""
    
    #Bug Fix (Cosmin): exceptions thrown in separate thread _send_and_release could not be caught
    #now we store the exception if it is thrown and raise it back in send_or_close
    try:
      self.bytes_sent = self._send(data)
    except Exception, e:
      self.TCPSendError = e
    
    self._quietly_release() # release the lock
 
  def _quietly_release(self):
    """Release the timeout lock and ignore if already released"""
    try:
      self.timeout_lock.release()
    except:
      pass
   
  def _send_or_close(self, data):
    """Raise the Timeout Error if no receipt.  Keep track by timeout_lock."""

    # acquire the lock, when it's release we'll carry on
    self.timeout_lock.acquire()

    # fork off a lock that'll release the lock at the timeout
    timerhandle = settimer(self.timeout, self._quietly_release, ())

    # fork off a send call so we can raise the exception in the main thread
    # the send call will also release our lock
    settimer(0, self._send_and_release, (data,))

    # block until either the timeout or _send finishes
    self.timeout_lock.acquire()
    self.timeout_lock.release()

    if self.bytes_sent: # send finished
      canceltimer(timerhandle)
      retdata = self.bytes_sent
      self.bytes_sent = None
      return retdata
    elif self.TCPSendError != None:
      #Bug Fix (Cosmin): exceptions thrown in separate thread _send_and_release could not be caught
      
      #we got an error within the separate thread that performed the send operation
      exception_to_throw = self.TCPSendError
      self.TCPSendError = None
      raise exception_to_throw
    else: # it timed out
      self.close()
      raise SocketTimeoutError

  def _recv_or_close(self, amount):
    """Raise the Timeout Error if no receipt.  Keep track by timeout_lock."""
    timerhandle = settimer(self.timeout, self._clobbersocket, ())
    try:
      retdata = self._recv(amount)
    except Exception, e:
      # if it's not the timeout, reraise...
      if self.timeout_lock.acquire(False):
        raise
      raise SocketTimeoutError
    
    # I acquired the lock, I should stop the timer because I succeeded...
    if self.timeout_lock.acquire(False):
      # even if this isn't in time, the lock prevents a race condition 
      # this is merely an optimization to prevent the timer from ever firing...
      canceltimer(timerhandle)
      self.timeout_lock.release() # Alper's bug 3/10/09
      return retdata
    else:
      raise SocketTimeoutError

  def _clobbersocket(self):
    """If I can acquire the lock without blocking, then close the socket to abort"""
    if self.timeout_lock.acquire(False):
      self.close()


############################
# Deprecated functions
##############################

# private function...
def sockettimeout_clobbersocket(sockobj,mylock):
  # if I can acquire the lock without blocking, then close the socket to abort
  if mylock.acquire(False):
    sockobj.close()

# if it fails to finish within the timeout, I close the socket and raise a
# SocketTimeout exception...
def sockettimeout_recv_or_close(sockobj, amount, timeout):
  # A lock I'll use for this attempt
  mylock = getlock()
  timerhandle = settimer(timeout,clobbersocket, (sockobj, mylock))
  try:
    retdata = sockobj.recv(amount)
  except Exception, e:
    # if it's not the timeout, reraise...
    if mylock.acquire(False):
      raise
    raise SocketTimeout
    
  # I acquired the lock, I should stop the timer because I succeeded...
  if mylock.acquire(False):
    # even if this isn't in time, the lock prevents a race condition 
    # this is merely an optimization to prevent the timer from ever firing...
    canceltimer(timerhandle)
    return retdata
  else:
    raise SocketTimeout


#end include sockettimeout.repy
servername = "satya.cs.washington.edu"
serverport = 10101

def centralizedadvertise_announce(key, value, ttlval):

  sockobj = timeout_openconn(servername,serverport, timeout=10)
  try:
    session_sendmessage(sockobj, "PUT|"+str(key)+"|"+str(value)+"|"+str(ttlval))
    response = session_recvmessage(sockobj)
    if response != 'OK':
      raise Exception, "Centralized announce failed '"+response+"'"
  finally:
    # BUG: This raises an error right now if the call times out ( #260 )
    # This isn't a big problem, but it is the "wrong" exception
    sockobj.close()
  
  return True
      



def centralizedadvertise_lookup(key, maxvals=100):
  sockobj = timeout_openconn(servername,serverport, timeout=10)
  try:
    session_sendmessage(sockobj, "GET|"+str(key)+"|"+str(maxvals))
    recvdata = session_recvmessage(sockobj)
    # worked
    if recvdata.endswith('OK'):
      return recvdata[:-len('OK')].split(',')
    raise Exception, "Centralized lookup failed"
  finally:
    # BUG: This raises an error right now if the call times out ( #260 )
    # This isn't a big problem, but it is the "wrong" exception
    sockobj.close()
      



#end include centralizedadvertise.repy

skipDHT = 0
previousDHTskip = 1
skipcentral = 0
previouscentralskip = 1

def announce(key, value, ttlval):
  global skipDHT
  global previousDHTskip
  global skipcentral
  global previouscentralskip


  if skipcentral == 0:
    try:
      centralizedadvertise_announce(key, value, ttlval)
      previouscentralskip = 1
    except Exception, e:
      print 'centralized:',e
      skipcentral = previouscentralskip + 1
      previouscentralskip = min(previouscentralskip * 2, 16)

  else:
    skipcentral = skipcentral - 1


  if skipDHT==0:
    try:
      openDHTadvertise.announce(key, value, ttlval)
      previousDHTskip = 1
    except Exception, e:
      print 'openDHT:',e
      skipDHT = previousDHTskip + 1
      previousDHTskip = min(previousDHTskip * 2, 16)
  else:
    skipDHT = skipDHT - 1



def uniq(a):
  retlist = []
  for item in a:
    if item not in retlist:
      retlist.append(item)

  return retlist



def lookup(key, maxvals=100, lookuptype=['central','opendht']):
  if 'central' in lookuptype:
    try:
      centralans = centralizedadvertise_lookup(key, maxvals)
    except Exception, e:
      centralans = []
  else:
    centralans = []

  if 'opendht' in lookuptype:
    try:
      dhtans = openDHTadvertise.lookup(key, maxvals)
    except Exception, e:
      dhtans = []

  else:
    dhtans = []

  return uniq(centralans + dhtans)


