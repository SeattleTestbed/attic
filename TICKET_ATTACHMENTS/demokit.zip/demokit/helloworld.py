if callfunc == 'initialize':
  print "Hello World"
