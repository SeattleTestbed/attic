import pickletools
from test import test_support
test_support.run_doctest(pickletools)
